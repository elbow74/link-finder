

#include <iostream>
#include <fstream>
#include <string>
using namespace std;

int main()
{
    int linkInput;

    cout << "Do you need a link or do you want to add a link\n";
    cout << "type 1 for need link and 2 for add link: ";
    cin >> linkInput;
    
    if (linkInput == 2) {
        int fileInput;
        cout << "Do you want to create a new file(1) or add to existing file(2)?\n";
        cout << "Enter 1 or 2: ";
        cin >> fileInput;
        if (fileInput == 1){
            string fileName;
            string linkTitle;
            cout << "What do you want to name this file: ";
            cin >> fileName;
            fstream linkFile(fileName, ios::in | ios::out | ios::app);
            string linkName;
            cout << "File opeened\n";
            cout << "Paste the link you want to add: ";
            cin >> linkName;
            cout << "what would you like to name this link: ";
            cin >> linkTitle;
            linkFile << linkTitle << ": " << linkName << endl;
            fstream titleFile("file titles", ios::in | ios::out | ios::app);
            titleFile << fileName << endl;

        } else {
            string fileName;
            string linkName;
            string linkTitle;
            string fileWords;
            cout << "Which file do want to add to: \n";
            ifstream titleFile("file titles");
            while (getline (titleFile, fileWords)) {
                cout << fileWords << endl;
            }
            titleFile.close();
            cin >> fileName;
            fstream linkFile(fileName, ios::in | ios::out | ios::app);
            cout << "File opeened\n";
            cout << "Paste the link you want to add: ";
            cin >> linkName;
            cout << "what would you like to name this like: ";
            cin >> linkTitle;
            linkFile << linkTitle << ": " << linkName << endl;
            
        }
        
        
        
    }else{
        string fileName;
        string fileWords;
        cout << "Which file is this link in: \n";
        ifstream titleFile("file titles");
        while (getline (titleFile, fileWords)) {
            cout << fileWords << endl;
        }
        titleFile.close();
        cin >> fileName;
        cout << "Here are the links: \n";
        string fileText;
        ifstream linkFile(fileName);
        while (getline (linkFile, fileText)) {
            cout << fileText << endl;
        }
        linkFile.close();
        
    }
 
}
